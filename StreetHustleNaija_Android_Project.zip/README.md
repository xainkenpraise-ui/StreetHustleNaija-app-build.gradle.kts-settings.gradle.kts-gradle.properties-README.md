# Street Hustle: Naija — Android Project

A full-screen Android wrapper around the playable Street Hustle: Naija MVP.

## Build
Open this folder in Android Studio and let Gradle sync. Then:
- Debug APK: Build > Build APK(s)
- Google Play release: Build > Generate Signed Bundle / APK > Android App Bundle

Configuration:
- compileSdk 36
- targetSdk 36
- minSdk 23
- Landscape orientation
- Full-screen immersive mode

Before publishing, add production art, icon assets, privacy policy if applicable, store screenshots, and sign the release bundle with your own upload key.
